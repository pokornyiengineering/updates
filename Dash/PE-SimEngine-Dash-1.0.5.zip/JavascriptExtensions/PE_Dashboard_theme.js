function pe_getTheme() {
    const theme = $prop('SimEnginePlugin.DashTheme');
    return theme;
}

function pe_color(item) {
    let theme = pe_getTheme();
    if (!theme || !pe_themes[theme]) theme = "Blue";
    return pe_themes[theme][item];
}
