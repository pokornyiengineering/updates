function _pe_val(name) {
    const v = $prop(name);
    return (v === null || v === undefined || v === '') ? null : v;
}

function _pe_firstVal(names, fallback) {
    for (let i = 0; i < names.length; i++) {
        const v = _pe_val(names[i]);
        if (v !== null) return v;
    }
    return (typeof fallback === 'undefined') ? null : fallback;
}

function _pe_na(name) {
    const v = _pe_val(name);
    return (v === null) ? 'N/A' : v;
}

function _pe_nonNegative(value) {
    const n = Number(value);
    return (isNaN(n) || n < 0) ? 0 : n;
}

// iRacing GTP cars send brake-bias migration on the ABS channel (GameData.ABSLevel),
// so there is no separate ABS value. Detect them by CarId (contains 'gtp', plus the
// LMDh cars whose id doesn't) so we can show B-MIG and hide ABS for them.
var _PE_IRACING_GTP_CARID_EXTRA = ['ferrari499p', 'bmwlmdh'];
function pe_isIRacingGTP() {
    if ($prop('DataCorePlugin.CurrentGame') !== 'IRacing') return false;
    const carId = $prop('DataCorePlugin.GameData.CarId');
    if (typeof carId !== 'string') return false;
    return carId.indexOf('gtp') >= 0 || _PE_IRACING_GTP_CARID_EXTRA.indexOf(carId) >= 0;
}

function pe_showItem(key) {
    if (key === 'bb') return true;
    // On iRacing GTP cars the ABS channel carries brake migration: hide ABS, force-show B-MIG.
    if (pe_isIRacingGTP()) {
        if (key === 'abs') return false;
        if (key === 'bbMig') return true;
    } else if (key === 'bbTarget') {
        return false;   // brake-bias target (dcBrakeMisc) is an iRacing-GTP-only value
    }
    const sel = $prop('SimEnginePlugin.DashItems');
    if (sel === null || sel === undefined || sel === '') return false;
    return (',' + sel + ',').indexOf(',' + key + ',') >= 0;
}

function pe_getTCValue() {
    return _pe_nonNegative(_pe_firstVal(['DataCorePlugin.GameData.TCLevel', 'DataCorePlugin.GameRawData.Telemetry.dcTractionControl'], 0));
}

function pe_getTC2Value() {
    return _pe_nonNegative(_pe_firstVal(['DataCorePlugin.GameRawData.PlayerNativeTelemetry.mTCCut', 'DataCorePlugin.GameRawData.Telemetry.dcTractionControl2'], 0));
}

function pe_getTCSlipValue() {
    return _pe_na('DataCorePlugin.GameRawData.PlayerNativeTelemetry.mTCSlip');
}

function pe_getABSValue() {
    return _pe_nonNegative(_pe_firstVal(['DataCorePlugin.GameData.ABSLevel', 'DataCorePlugin.GameRawData.Telemetry.dcABS'], 0));
}

function pe_getEngineBrakeValue() {
    return _pe_na('DataCorePlugin.GameRawData.Telemetry.dcEngineBraking');
}

function pe_getBBValue() {
    const bb = Number($prop('BrakeBias'));
    return (isNaN(bb) || bb <= 0) ? 'N/A' : bb.toFixed(1);
}

function pe_getBrkMigValue() {
    // GTP cars report migration on the ABS channel; other cars use native mMigration.
    // Read the ABS channel raw (not pe_getABSValue) so negative migration (-5..5) isn't clamped to 0.
    if (pe_isIRacingGTP()) return _pe_firstVal(['DataCorePlugin.GameData.ABSLevel', 'DataCorePlugin.GameRawData.Telemetry.dcABS'], 'N/A');
    return _pe_na('DataCorePlugin.GameRawData.PlayerNativeTelemetry.mMigration');
}

function pe_getBBTargetValue() {
    // iRacing GTP brake-bias target (only meaningful on GTP cars).
    return _pe_na('DataCorePlugin.GameRawData.Telemetry.dcBrakeMisc');
}

function pe_getMapValue() {
    return _pe_firstVal(['DataCorePlugin.GameData.EngineMap', 'DataCorePlugin.GameRawData.Telemetry.dcEngineMap'], 'N/A');
}

function pe_getMapRegenValue() {
    return _pe_na('DataCorePlugin.GameRawData.Telemetry.dcMGUKRegenGain');
}

function pe_getMixValue() {
    return _pe_firstVal(['DataCorePlugin.GameRawData.Telemetry.dcFuelMixture'], 'N/A');
}

function pe_getShapeValue() {
    return _pe_na('DataCorePlugin.GameRawData.Telemetry.dcThrottleShape');
}

function pe_getTurboValue() {
    return _pe_nonNegative(_pe_firstVal(['DataCorePlugin.GameData.TurboPercent', 'DataCorePlugin.GameData.NewData.TurboPercent'], 0));
}

function pe_getBoostValue() {
    return _pe_firstVal(['DataCorePlugin.GameData.TurboPressure', 'DataCorePlugin.GameRawData.Telemetry.ManifoldPress'], 'N/A');
}

function pe_getMGUKValue() {
    return _pe_na('DataCorePlugin.GameRawData.Telemetry.dcMGUKDeployMode');
}

function pe_getERSValue() {
    return _pe_firstVal(['DataCorePlugin.GameRawData.Telemetry.dcMGUKDeployMode', 'DataCorePlugin.GameData.ERSPercent'], 'N/A');
}

function pe_getSOCValue() {
    // iRacing exposes SOC as a 0..1 fraction; scale to percent.
    if ($prop('DataCorePlugin.CurrentGame') === 'IRacing') {
        const soc = $prop('DataCorePlugin.GameRawData.Telemetry.EnergyERSBatteryPct');
        if (soc !== null && soc !== undefined && soc !== '') return _pe_nonNegative(Math.round(soc * 100));
    }
    return _pe_nonNegative(_pe_firstVal(['DataCorePlugin.GameRawData.PlayerNativeTelemetry.mSoC', 'ERSPercent'], 0));
}

function pe_getFrontARBValue() {
    return _pe_na('DataCorePlugin.GameRawData.Telemetry.dcAntiRollFront');
}

function pe_getRearARBValue() {
    return _pe_na('DataCorePlugin.GameRawData.Telemetry.dcAntiRollRear');
}

function pe_getDiffValue() {
    return _pe_firstVal(['DataCorePlugin.GameRawData.PlayerCarSetup.m_onThrottle', 'DataCorePlugin.GameRawData.Telemetry.dcDiffEntry'], 'N/A');
}

function pe_getDiffEntryValue() {
    return _pe_na('DataCorePlugin.GameRawData.Telemetry.dcDiffEntry');
}

function pe_getDiffMidValue() {
    return _pe_na('DataCorePlugin.GameRawData.Telemetry.dcDiffMiddle');
}

function pe_getDiffExitValue() {
    return _pe_na('DataCorePlugin.GameRawData.Telemetry.dcDiffExit');
}

function pe_getOilPressValue() {
    return _pe_firstVal(['DataCorePlugin.GameData.OilPressure', 'OilPressure'], 'N/A');
}

function pe_getOilTempValue() {
    return _pe_firstVal(['DataCorePlugin.GameData.OilTemperature', 'OilTemperature'], 'N/A');
}

// ---- Change-popup system --------------------------------------------------
// Shows a popup for a few seconds after a tracked control value changes.
// To add a control (TC, ABS, ...) just add an entry below — each key gets its
// own independent timer, and pe_showPopUp('<key>') binds to its popup element.
var PE_POPUP_DURATION_MS = 3000;

var PE_POPUP_CONFIG = [
    { key: 'bb',      label: 'BRAKE BIAS', ignore: ['N/A', '', null], getValue: pe_getBBValue },
    { key: 'bbMig',   label: 'B-MIG',      ignore: ['N/A', '', null], getValue: pe_getBrkMigValue },
    { key: 'bbTarget',label: 'BB TARGET',  ignore: ['N/A', '', null], getValue: function () { return pe_isIRacingGTP() ? pe_getBBTargetValue() : null; } },
    { key: 'tc',      label: 'TC',         ignore: ['N/A', '', null], getValue: pe_getTCValue },
    { key: 'tc2',     label: 'TC2',        ignore: ['N/A', '', null], getValue: pe_getTC2Value },
    { key: 'tcSlip',  label: 'TC SLIP',    ignore: ['N/A', '', null], getValue: pe_getTCSlipValue },
    { key: 'abs',     label: 'ABS',        ignore: ['N/A', '', null], getValue: function () { return pe_isIRacingGTP() ? null : pe_getABSValue(); } },
    { key: 'map',     label: 'MAP',        ignore: ['N/A', '', null], getValue: pe_getMapValue },
    { key: 'mix',     label: 'MIX',        ignore: ['N/A', '', null], getValue: pe_getMixValue },
    { key: 'deploy',  label: 'DEPLOY',     ignore: ['N/A', '', null], getValue: pe_getMGUKValue },
    { key: 'shape',   label: 'THR SHAPE',  ignore: ['N/A', '', null], getValue: pe_getShapeValue },
    { key: 'farb',    label: 'FRONT ARB',  ignore: ['N/A', '', null], getValue: pe_getFrontARBValue },
    { key: 'rarb',    label: 'REAR ARB',   ignore: ['N/A', '', null], getValue: pe_getRearARBValue },
];

var _pe_popup_fallback = null;
function _pe_popupUpdate() {
    // Keep the tracker on `root` so it is SHARED across the popup's separate widget JS
    // contexts: the visibility binding (pe_showChangePopUp, in InfoPopUp.djson) runs from
    // load and seeds it, while the label/value bindings (in SettingPopUp.djson) only start
    // when the popup first shows. With per-context state the value tracker would seed on the
    // first change and swallow it (popup visible but blank until the 2nd change).
    var st;
    if (typeof root !== 'undefined' && root !== null) {
        if (!root['_pe_popup']) root['_pe_popup'] = { tracked: {}, lastFrame: 0, now: 0 };
        st = root['_pe_popup'];
    } else {
        if (_pe_popup_fallback === null) _pe_popup_fallback = { tracked: {}, lastFrame: 0, now: 0 };
        st = _pe_popup_fallback;
    }
    const now = new Date().getTime();
    // Throttle: recompute at most once per frame (~16ms); reuse state otherwise.
    if (now - st.lastFrame < 16) return st;
    st.lastFrame = now;

    for (let i = 0; i < PE_POPUP_CONFIG.length; i++) {
        const cfg = PE_POPUP_CONFIG[i];
        const val = cfg.getValue();
        if (cfg.ignore && cfg.ignore.indexOf(val) >= 0) continue;

        const t = st.tracked[cfg.key];
        if (typeof t === 'undefined') {
            // First valid read only seeds the tracker (no popup on load / car change).
            st.tracked[cfg.key] = { value: val, changedAt: 0 };
        } else if (val !== t.value) {
            t.value = val;
            t.changedAt = now;
        }
    }
    st.now = now;
    return st;
}

function _pe_popupActive(key) {
    const st = _pe_popupUpdate();
    const t = st.tracked[key];
    return !!(t && t.changedAt && (st.now - t.changedAt) < PE_POPUP_DURATION_MS);
}

// True while the given control changed recently (e.g. 'bb', 'tc', 'abs').
// Each key is independent, so multiple popups can be active at once.
function pe_showPopUp(key) {
    return _pe_popupActive(key);
}

// True while ANY tracked control changed recently (for a single shared popup).
function pe_showChangePopUp() {
    for (let i = 0; i < PE_POPUP_CONFIG.length; i++) {
        if (_pe_popupActive(PE_POPUP_CONFIG[i].key)) return true;
    }
    return false;
}

// Drives the popup overlay GROUP's visibility (not the visible box). SimHub only runs the
// label/value bindings while the overlay is shown and isolates each binding's state, so they
// seed on the first show and would miss the first change. Keep the overlay 'shown' (but
// visually empty — the box is gated separately on pe_showChangePopUp) for a moment after load
// so those bindings evaluate once and seed. After the warm-up it just follows real changes.
var _pe_warmupStart = 0;
function pe_popupTrigger() {
    const now = new Date().getTime();
    if (_pe_warmupStart === 0) _pe_warmupStart = now;
    if ((now - _pe_warmupStart) < 2500) return true;   // warm-up window after load
    return pe_showChangePopUp();
}

// Label / value of the most-recently changed active control (for shared popup text).
function _pe_popupCurrent() {
    const st = _pe_popupUpdate();
    let best = null;
    for (let i = 0; i < PE_POPUP_CONFIG.length; i++) {
        const cfg = PE_POPUP_CONFIG[i];
        const t = st.tracked[cfg.key];
        if (t && t.changedAt && (st.now - t.changedAt) < PE_POPUP_DURATION_MS) {
            if (!best || t.changedAt > best.changedAt) {
                best = { label: cfg.label, value: t.value, changedAt: t.changedAt };
            }
        }
    }
    return best;
}
function pe_getPopUpLabel() { const c = _pe_popupCurrent(); return c ? c.label : ''; }
function pe_getPopUpValue() { const c = _pe_popupCurrent(); return c ? c.value : ''; }

// ---- Warning popup (flags / low fuel / incidents) -------------------------
// One high-priority warning at a time (Yellow > Blue > Incident > Low fuel).
//  - Yellow / Blue flag: single centered line, shown while the flag is active.
//  - Low fuel: two lines (FUEL + laps remaining), shown while below the threshold.
//  - Incident (iRacing): two lines (INC + count/limit), flashed for a few seconds
//    whenever the incident count goes up.
// Colours: yellow flag = gold, blue flag = blue, low fuel / incident = red.
var PE_WARN_COLOR_YELLOW = '#FFFFD700';
var PE_WARN_COLOR_BLUE   = '#FF0072FF';
var PE_WARN_COLOR_RED    = '#FFE10000';
var PE_WARN_LOW_FUEL_LAPS = 3;   // warn when fewer than this many laps of fuel remain

function _pe_num(name) {
    const v = $prop(name);
    const n = Number(v);
    return (v === null || v === undefined || v === '' || isNaN(n)) ? null : n;
}

function pe_isBlueFlag()   { return _pe_num('DataCorePlugin.GameData.Flag_Blue') > 0; }
function pe_isYellowFlag() { return _pe_num('DataCorePlugin.GameData.Flag_Yellow') > 0; }

// Low fuel: fewer than PE_WARN_LOW_FUEL_LAPS laps of fuel left (needs a valid estimate).
function pe_isLowFuel() {
    const laps = _pe_num('DataCorePlugin.Computed.Fuel_RemainingLaps');
    if (laps === null || laps <= 0) return false;
    return laps < PE_WARN_LOW_FUEL_LAPS;
}
function _pe_fuelLapsText() {
    const laps = _pe_num('DataCorePlugin.Computed.Fuel_RemainingLaps');
    return (laps === null) ? '' : laps.toFixed(1);
}

// iRacing incident count vs the session limit ("x / limit"; unlimited -> just the count).
function _pe_incidentCount() { return _pe_num('DataCorePlugin.GameRawData.Telemetry.PlayerCarMyIncidentCount'); }
function _pe_incidentLimit() {
    const n = Number($prop('DataCorePlugin.GameRawData.SessionData.WeekendInfo.WeekendOptions.IncidentLimit'));
    return (isNaN(n) || n <= 0) ? null : n;   // "unlimited" / non-numeric -> no limit
}
function _pe_incidentText() {
    const c = _pe_incidentCount();
    if (c === null) return '';
    const lim = _pe_incidentLimit();
    return (lim === null) ? String(c) : (c + '/' + lim);
}
var _pe_inc_fallback = null;
function pe_isIncidentFlash() {
    if ($prop('DataCorePlugin.CurrentGame') !== 'IRacing') return false;
    const c = _pe_incidentCount();
    if (c === null) return false;
    var st;
    if (typeof root !== 'undefined' && root !== null) {
        if (!root['_pe_inc']) root['_pe_inc'] = { last: null, changedAt: 0 };
        st = root['_pe_inc'];
    } else {
        if (_pe_inc_fallback === null) _pe_inc_fallback = { last: null, changedAt: 0 };
        st = _pe_inc_fallback;
    }
    const now = new Date().getTime();
    if (st.last === null) { st.last = c; return false; }   // seed on load, no flash
    if (c > st.last) { st.last = c; st.changedAt = now; }   // new incident -> flash
    else if (c < st.last) { st.last = c; }                  // reset (new session), no flash
    return !!(st.changedAt && (now - st.changedAt) < PE_POPUP_DURATION_MS);
}

// Highest-priority active warning (or null). mode 'single' = flag word; 'dual' = label + value.
function _pe_warnCurrent() {
    if (pe_isYellowFlag())    return { mode: 'single', color: PE_WARN_COLOR_YELLOW, text: 'YELLOW' };
    if (pe_isBlueFlag())      return { mode: 'single', color: PE_WARN_COLOR_BLUE,   text: 'BLUE' };
    if (pe_isIncidentFlash()) return { mode: 'dual',   color: PE_WARN_COLOR_RED, label: 'INC',  value: _pe_incidentText() };
    if (pe_isLowFuel())       return { mode: 'dual',   color: PE_WARN_COLOR_RED, label: 'FUEL', value: _pe_fuelLapsText() };
    return null;
}

function pe_showWarn()       { return _pe_warnCurrent() !== null; }
function pe_showWarnSingle() { const w = _pe_warnCurrent(); return !!(w && w.mode === 'single'); }
function pe_showWarnDual()   { const w = _pe_warnCurrent(); return !!(w && w.mode === 'dual'); }
function pe_warnColor()      { const w = _pe_warnCurrent(); return w ? w.color : '#00000000'; }
function pe_warnSingleText() { const w = _pe_warnCurrent(); return (w && w.mode === 'single') ? w.text : ''; }
function pe_warnDualLabel()  { const w = _pe_warnCurrent(); return (w && w.mode === 'dual') ? w.label : ''; }
function pe_warnDualValue()  { const w = _pe_warnCurrent(); return (w && w.mode === 'dual') ? w.value : ''; }
// Black text reads on gold; white on blue/red.
function pe_warnTextColor()  { const w = _pe_warnCurrent(); return (w && w.color === PE_WARN_COLOR_YELLOW) ? '#FF000000' : '#FFFFFFFF'; }

