function pe_lowerLeftBarTitle() {
    return $prop('SimEnginePlugin.LowerLeftBarTitle') ? $prop('SimEnginePlugin.LowerLeftBarTitle') : 'Unassigned';
}

function pe_lowerLeftBarValue() {
    return $prop('SimEnginePlugin.LowerLeftBarValue') ? $prop('SimEnginePlugin.LowerLeftBarValue') : 'N/A';
}

function pe_lowerMiddleBarTitle() {
    return $prop('SimEnginePlugin.LowerMiddleBarTitle') ? $prop('SimEnginePlugin.LowerMiddleBarTitle') : 'Unassigned';
}

function pe_lowerMiddleBarValue() {
    return $prop('SimEnginePlugin.LowerMiddleBarValue') ? $prop('SimEnginePlugin.LowerMiddleBarValue') : 'N/A';
}

function pe_lowerRightBarTitle() {
    return $prop('SimEnginePlugin.LowerRightBarTitle') ? $prop('SimEnginePlugin.LowerRightBarTitle') : 'Unassigned';
}

function pe_lowerRightBarValue() {
    return $prop('SimEnginePlugin.LowerRightBarValue') ? $prop('SimEnginePlugin.LowerRightBarValue') : 'N/A';
}

function pe_lowerLeftBarChanged() {
    return $prop('SimEnginePlugin.LowerLeftBarChanged') == true;
}

function pe_lowerMiddleBarChanged() {
    return $prop('SimEnginePlugin.LowerMiddleBarChanged') == true;
}

function pe_lowerRightBarChanged() {
    return $prop('SimEnginePlugin.LowerRightBarChanged') == true;
}


// Per-device live values come from whichever device has "Feed the SimEngine Dash" enabled
// (the plugin routes these device-independent Dash.* properties to that single feeder device).
function pe_getBitepointValue() {
    return $prop('SimEnginePlugin.Dash.ClutchBitePoint')/100;
}

function pe_getBitepointPresetName() {
    return $prop('SimEnginePlugin.Dash.BitePointPresetName');
}

function pe_showDualClutchOverlay() {
    return $prop('SimEnginePlugin.Dash.LiveAdjustmentActive');
}

function pe_getBrakeMagicLevel() {
    return $prop('SimEnginePlugin.Dash.BrakeMagicLevel')/100;
}

function pe_showBrakeMagicOverlay() {
    return $prop('SimEnginePlugin.Dash.BrakeMagicActive');
}

function pe_getLaunchControlState() {
    // 0 = idle, 1 = preparing/arming, 2 = active
    return $prop('SimEnginePlugin.Dash.LaunchControlState');
}

function pe_showLaunchControlOverlay() {
    return pe_getLaunchControlState() >= 1;
}

function pe_getLaunchControlOutput() {
    return $prop('SimEnginePlugin.Dash.LaunchControlOutput')/100;
}

function pe_getLaunchControlBitePoint() {
    return $prop('SimEnginePlugin.Dash.LaunchControlBitePoint')/100;
}

function pe_getLaunchControlReleaseTime() {
    return $prop('SimEnginePlugin.Dash.LaunchControlReleaseMs')/1000;
}

function pe_launchControlStateText() {
    return pe_getLaunchControlState() >= 2 ? 'ACTIVE' : 'ARMING';
}

function pe_launchControlBadgeColor() {
    return pe_getLaunchControlState() >= 2 ? pe_color('launchControlTextDefault') : pe_color('launchControlArming');
}
